import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { deleteUser, onAuthStateChanged, signOut as fbSignOut, User } from 'firebase/auth';
import { deleteDoc, doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from './firebase';

export type Profile = { first?: string; last?: string; name?: string; dob?: string; username?: string; photoUrl?: string | null; onboarding?: string | null; email?: string | null; phone?: string | null };
export type Draft = { method: 'email' | 'phone'; contact: string; password: string; verificationId: string; first: string; last: string; dob: string };

type Ctx = {
  user: User | null;
  /** undefined = still loading, null = signed in but no profile yet */
  profile: Profile | null | undefined;
  profileError: string | null; retryProfile: () => void;
  loading: boolean;
  emailPending: boolean; reloadUser: () => Promise<void>;
  blocked: boolean; blockUnderage: () => Promise<void>; clearBlocked: () => void;
  draft: Draft; setDraft: (d: Partial<Draft>) => void;
  signOut: () => Promise<void>;
};
const AuthCtx = createContext<Ctx>(null as unknown as Ctx);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [, tick] = useState(0);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<Profile | null | undefined>(undefined);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [key, setKey] = useState(0);
  const [blocked, setBlocked] = useState(false);
  const [draft, setD] = useState<Draft>({ method: 'phone', contact: '', password: '', verificationId: '', first: '', last: '', dob: '' });

  useEffect(() => onAuthStateChanged(auth, (u) => { setUser(u); setLoading(false); if (!u) setProfile(undefined); }), []);

  // Live profile (users/{uid}). Drives which onboarding step is shown.
  useEffect(() => {
    if (!user) return;
    setProfileError(null);
    return onSnapshot(doc(db, 'users', user.uid),
      (s) => { setProfile(s.exists() ? (s.data() as Profile) : null); setProfileError(null); },
      (e) => setProfileError(String((e as { code?: string }).code ?? e)));
  }, [user?.uid, key]);

  const reloadUser = useCallback(async () => { if (auth.currentUser) { await auth.currentUser.reload(); setUser(auth.currentUser); tick((n) => n + 1); } }, []);

  const value = useMemo<Ctx>(() => ({
    user, profile, profileError, retryProfile: () => setKey((k) => k + 1), loading,
    emailPending: !!user && user.providerData.some((p) => p.providerId === 'password') && !user.emailVerified,
    reloadUser,
    blocked, clearBlocked: () => setBlocked(false),
    // Under 18: the half-created account is deleted so it cannot be used.
    blockUnderage: async () => {
      setBlocked(true);
      const u = auth.currentUser;
      try { if (u) { await deleteDoc(doc(db, 'users', u.uid)).catch(() => undefined); await deleteUser(u); } }
      catch { await fbSignOut(auth).catch(() => undefined); }
    },
    draft, setDraft: (d) => setD((p) => ({ ...p, ...d })),
    signOut: async () => { await fbSignOut(auth); setD({ method: 'phone', contact: '', password: '', verificationId: '', first: '', last: '', dob: '' }); },
  }), [user, profile, profileError, loading, blocked, draft, reloadUser, tick]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
