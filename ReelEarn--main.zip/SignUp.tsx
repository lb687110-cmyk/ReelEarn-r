import React, { useEffect, useRef, useState } from 'react';
import { Image, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker, { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { createUserWithEmailAndPassword, PhoneAuthProvider, sendEmailVerification, signInWithCredential } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAuth } from '../AuthContext';
import { CountryPicker } from '../CountryPicker';
import { COUNTRIES, Country, validNational } from '../countries';
import { claimUsername, finishOnboarding, uploadAvatar, usernameAvailable } from '../db';
import { auth, db } from '../firebase';
import { AGE_MSG, EMAIL_RE, NAME_RE, USERNAME_RE, ageOn, friendly, iso } from '../lib';
import { usePhoneVerifier } from '../phone';
import { C } from '../theme';
import { Btn, ErrorText, Field, Link, OtpBoxes, Screen, Sub, Title } from '../ui';

type P = NativeStackScreenProps<any>;
const mmss = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
const useCountdown = (start: number) => {
  const [wait, setWait] = useState(start);
  useEffect(() => { const t = setInterval(() => setWait((w) => Math.max(0, w - 1)), 1000); return () => clearInterval(t); }, []);
  return [wait, setWait] as const;
};

/* Step 5: Create account */
export function SignUpLanding({ navigation }: P) {
  return (
    <Screen onBack={() => navigation.goBack()}>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <Text style={s.big}>ReelEarn</Text>
        <Sub style={{ textAlign: 'center', marginTop: 10 }}>Sign up to share reels and stories and grow your audience. It only takes a minute.</Sub>
        <Btn title="Create new account" onPress={() => navigation.navigate('ChooseMethod')} style={{ marginTop: 24 }} />
        <View style={{ alignItems: 'center', marginTop: 22 }}><Link title="Log in" onPress={() => navigation.navigate('Login')} /></View>
      </View>
    </Screen>
  );
}

/* Step 6: Choose sign-up method */
export function ChooseMethod({ navigation }: P) {
  const { setDraft } = useAuth();
  const pick = (method: 'email' | 'phone') => { setDraft({ method, contact: '', password: '' }); navigation.navigate('EnterContact'); };
  return (
    <Screen onBack={() => navigation.goBack()}>
      <Title>Create account</Title>
      <Sub>Choose how you want to sign up.</Sub>
      <Btn title="Sign up with mobile number" onPress={() => pick('phone')} />
      <Btn title="Sign up with email" variant="outline" onPress={() => pick('email')} />
      <View style={{ alignItems: 'center', marginTop: 22 }}><Link title="I already have an account" onPress={() => navigation.navigate('Login')} /></View>
    </Screen>
  );
}

/* Step 7: Enter mobile number (country code, default +91 India) or email */
export function EnterContact({ navigation }: P) {
  const { draft, setDraft } = useAuth();
  const { element, send } = usePhoneVerifier();
  const isPhone = draft.method === 'phone';
  const [country, setCountry] = useState<Country>(COUNTRIES[0]);
  const [num, setNum] = useState('');
  const [email, setEmail] = useState(draft.method === 'email' ? draft.contact : '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function next() {
    setErr(null);
    if (!isPhone) {
      const e = email.trim().toLowerCase();
      if (!EMAIL_RE.test(e)) return setErr('Enter a valid email address.');
      setDraft({ contact: e }); navigation.navigate('CreatePassword'); return;
    }
    if (!validNational(country, num)) return setErr(country.dial === '+91' ? 'Enter a valid 10-digit mobile number.' : 'Enter a valid mobile number.');
    setBusy(true);
    try {
      const contact = country.dial + num;
      const verificationId = await send(contact);
      setDraft({ contact, verificationId });
      navigation.navigate('VerifyCode', { purpose: 'signup' });
    } catch (e) { setErr(friendly(e)); } finally { setBusy(false); }
  }
  return (
    <Screen onBack={() => navigation.goBack()}>
      {element}
      <Title>{isPhone ? "What's your mobile number?" : "What's your email address?"}</Title>
      <Sub>{isPhone ? "Enter the mobile number you'll use for your account. We'll text you a verification code." : 'Use an email you can access. We will send a verification link to it.'}</Sub>
      {isPhone
        ? <View style={{ flexDirection: 'row', marginBottom: 6 }}>
            <CountryPicker value={country} onChange={(c) => { setCountry(c); setNum(num.slice(0, c.max)); }} />
            <View style={{ flex: 1 }}><Field label="Mobile number" value={num} onChangeText={(t) => setNum(t.replace(/\D/g, '').slice(0, country.max))} keyboardType="number-pad" textContentType="telephoneNumber" maxLength={country.max} /></View>
          </View>
        : <Field label="Email address" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" textContentType="emailAddress" />}
      {isPhone ? <Text style={s.note}>{country.dial === '+91' ? 'India: 10-digit number, no 0 at the start.' : `Enter the number without ${country.dial}.`}</Text> : null}
      <ErrorText>{err}</ErrorText>
      <Btn title="Next" onPress={next} loading={busy} disabled={isPhone ? !num : !email} />
      <View style={{ alignItems: 'center', marginTop: 18 }}>
        <Link title={isPhone ? 'Sign up with email instead' : 'Sign up with mobile number instead'} onPress={() => { setDraft({ method: isPhone ? 'email' : 'phone' }); setErr(null); }} />
      </View>
    </Screen>
  );
}

/* Step 8 (mobile): 6-digit text code with resend timer. Also used to log in with a mobile number. */
export function VerifyCode({ navigation }: P) {
  const { draft, setDraft } = useAuth();
  const { element, send } = usePhoneVerifier();
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [wait, setWait] = useCountdown(60);

  async function verify(token: string) {
    if (busy || token.length !== 6) return;
    setBusy(true); setErr(null);
    try { await signInWithCredential(auth, PhoneAuthProvider.credential(draft.verificationId, token)); } // success: signed in, the app moves on by itself
    catch (e) { setErr(friendly(e)); setCode(''); } finally { setBusy(false); }
  }
  async function resend() {
    setErr(null); setNote(null);
    try { const id = await send(draft.contact); setDraft({ verificationId: id }); setWait(60); setNote('A new code is on its way.'); }
    catch (e) { setErr(friendly(e)); }
  }
  return (
    <Screen onBack={() => navigation.goBack()}>
      {element}
      <Title>Enter confirmation code</Title>
      <Sub>We sent a 6-digit code to {draft.contact}.</Sub>
      <OtpBoxes value={code} onChange={(d) => { setCode(d); if (d.length === 6) verify(d); }} autoFocus />
      <ErrorText>{err}</ErrorText>
      {note ? <Text style={{ color: C.green, marginBottom: 12 }}>{note}</Text> : null}
      <Btn title="Next" onPress={() => verify(code)} loading={busy} disabled={code.length !== 6} />
      <View style={{ alignItems: 'center', marginTop: 18 }}>
        {wait > 0 ? <Text style={{ color: C.mute }}>Resend code ({mmss(wait)})</Text> : <Link title="Resend code" onPress={resend} />}
      </View>
    </Screen>
  );
}

/* Step 9 (email): Create password. This creates the account and emails the verification link. */
export function CreatePassword({ navigation }: P) {
  const { draft, setDraft } = useAuth();
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const strength = pw.length < 6 ? 'short' : /\d/.test(pw) && /[A-Za-z]/.test(pw) && pw.length >= 8 ? 'strong' : 'ok';
  async function next() {
    if (pw.length < 6) return setErr('Your password needs at least 6 characters.');
    setBusy(true); setErr(null);
    try {
      const cred = await createUserWithEmailAndPassword(auth, draft.contact, pw);
      await sendEmailVerification(cred.user).catch(() => undefined); // the next screen lets the person resend it
      setDraft({ password: '' });
    } catch (e) { setErr(friendly(e)); } finally { setBusy(false); }
  }
  return (
    <Screen onBack={() => navigation.goBack()}>
      <Title>Create a password</Title>
      <Sub>Use at least 6 characters. Mixing letters, numbers and symbols makes it harder to guess.</Sub>
      <Field label="Password" value={pw} onChangeText={setPw} secureTextEntry={!show} autoCapitalize="none" textContentType="newPassword"
        ok={pw.length >= 6} hint={!pw ? undefined : strength === 'short' ? `${6 - pw.length} more character${6 - pw.length === 1 ? '' : 's'}` : strength === 'strong' ? 'Strong password' : 'Good. Add numbers or symbols to make it stronger.'}
        right={<Pressable onPress={() => setShow(!show)} hitSlop={10} accessibilityLabel={show ? 'Hide password' : 'Show password'}><Text style={{ color: C.mute, fontWeight: '600' }}>{show ? 'Hide' : 'Show'}</Text></Pressable>} />
      <ErrorText>{err}</ErrorText>
      <Btn title="Next" onPress={next} loading={busy} disabled={pw.length < 6} />
    </Screen>
  );
}

/* Step 8 (email): the person taps the link we emailed; this screen notices and moves on. */
export function VerifyEmail() {
  const { user, reloadUser, signOut } = useAuth();
  const [wait, setWait] = useCountdown(60);
  const [err, setErr] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { const t = setInterval(() => { reloadUser().catch(() => undefined); }, 4000); return () => clearInterval(t); }, [reloadUser]);
  async function check() { setBusy(true); setErr(null); try { await reloadUser(); if (!auth.currentUser?.emailVerified) setErr('Not verified yet. Tap the link in the email, then try again.'); } catch (e) { setErr(friendly(e)); } finally { setBusy(false); } }
  async function resend() {
    setErr(null); setNote(null);
    try { if (auth.currentUser) await sendEmailVerification(auth.currentUser); setWait(60); setNote('A new link is on its way.'); } catch (e) { setErr(friendly(e)); }
  }
  return (
    <Screen scroll={false}>
      <Title>Check your email</Title>
      <Sub>We sent a verification link to {user?.email}. Tap it, then come back here. This screen continues automatically.</Sub>
      <ErrorText>{err}</ErrorText>
      {note ? <Text style={{ color: C.green, marginBottom: 12 }}>{note}</Text> : null}
      <Btn title="I've verified my email" onPress={check} loading={busy} />
      <View style={{ alignItems: 'center', marginTop: 18, gap: 18 }}>
        {wait > 0 ? <Text style={{ color: C.mute }}>Resend link ({mmss(wait)})</Text> : <Link title="Resend link" onPress={resend} />}
        <Link title="Use a different email" onPress={signOut} />
      </View>
    </Screen>
  );
}

/* Step 10: First name and last name */
export function BasicInfo() {
  const { user, setDraft } = useAuth();
  const [first, setFirst] = useState('');
  const [last, setLast] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  async function next() {
    if (!user) return;
    const f = first.trim().replace(/\s+/g, ' '), l = last.trim().replace(/\s+/g, ' ');
    if (!NAME_RE.test(f)) return setErr('Enter your first name using letters only.');
    if (!NAME_RE.test(l)) return setErr('Enter your last name (surname) using letters only.');
    setBusy(true); setErr(null);
    try {
      await setDoc(doc(db, 'users', user.uid), { first: f, last: l, name: `${f} ${l}`, email: user.email ?? null, phone: user.phoneNumber ?? null }, { merge: true });
      setDraft({ first: f, last: l }); // the live profile changes, so the next step appears by itself
    } catch (e) { setErr(friendly(e)); } finally { setBusy(false); }
  }
  return (
    <Screen scroll>
      <Title>What's your name?</Title>
      <Sub>Enter your first name and last name (surname). You can change how your name appears later.</Sub>
      <Field label="First name" value={first} onChangeText={setFirst} autoCapitalize="words" textContentType="givenName" maxLength={40} />
      <Field label="Last name / Surname" value={last} onChangeText={setLast} autoCapitalize="words" textContentType="familyName" maxLength={40} />
      <ErrorText>{err}</ErrorText>
      <Btn title="Next" onPress={next} loading={busy} disabled={!first.trim() || !last.trim()} />
    </Screen>
  );
}

/* Step 11: Date of birth and 18+ check */
export function BirthDate() {
  const { user, blockUnderage } = useAuth();
  const today = new Date();
  const [dob, setDob] = useState<Date>(new Date(today.getFullYear() - 18, today.getMonth(), today.getDate()));
  const [touched, setTouched] = useState(false);
  const [open, setOpen] = useState(Platform.OS === 'ios');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const age = ageOn(dob);
  const minor = touched && age < 18;
  function onChange(e: DateTimePickerEvent, d?: Date) {
    if (Platform.OS === 'android') setOpen(false);
    if (e.type === 'set' && d) { setDob(d); setTouched(true); setErr(null); }
  }
  async function next() {
    if (!touched || !user) return;
    if (age < 18) { await blockUnderage(); return; } // the account is deleted and the "18+" screen appears
    setBusy(true); setErr(null);
    try { await setDoc(doc(db, 'users', user.uid), { dob: iso(dob) }, { merge: true }); }
    catch (e) { setErr(friendly(e)); } finally { setBusy(false); }
  }
  return (
    <Screen>
      <Title>What's your date of birth?</Title>
      <Sub>You must be 18 or older to use ReelEarn. Your date of birth is private and is not shown on your profile.</Sub>
      <Pressable onPress={() => setOpen(true)} accessibilityRole="button" accessibilityLabel="Choose date of birth" style={[s.dobBtn, minor && { borderColor: C.red }]}>
        <Text style={{ color: touched ? C.text : C.mute, fontSize: 16 }}>{touched ? dob.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Select date of birth'}</Text>
        {touched ? <Text style={{ color: minor ? C.red : C.mute }}>{age} years old</Text> : null}
      </Pressable>
      {open ? <DateTimePicker value={dob} mode="date" display={Platform.OS === 'ios' ? 'spinner' : 'default'} maximumDate={today} minimumDate={new Date(1900, 0, 1)} onChange={onChange} themeVariant="dark" textColor={C.text} /> : null}
      {minor ? <Text accessibilityLiveRegion="polite" style={s.errBox}>{AGE_MSG}</Text> : null}
      <ErrorText>{err}</ErrorText>
      <Btn title="Next" onPress={next} loading={busy} disabled={!touched} />
    </Screen>
  );
}

/* Step 12: Unique username with real-time availability check */
type Avail = 'idle' | 'checking' | 'ok' | 'taken' | 'invalid' | 'error';
export function Username() {
  const { user, profile } = useAuth();
  const first = profile?.first ?? '', last = profile?.last ?? '';
  const seed = `${first}${last ? '.' + last : ''}`.toLowerCase().replace(/[^a-z0-9._]/g, '').slice(0, 20);
  const [u, setU] = useState(seed.length >= 3 ? seed : '');
  const [st, setSt] = useState<Avail>('idle');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const seq = useRef(0);

  useEffect(() => {
    if (!u) { setSt('idle'); return; }
    if (!USERNAME_RE.test(u)) { setSt('invalid'); return; }
    setSt('checking');
    const my = ++seq.current;
    const t = setTimeout(async () => {
      try { const ok = await usernameAvailable(u); if (my === seq.current) setSt(ok ? 'ok' : 'taken'); }
      catch { if (my === seq.current) setSt('error'); }
    }, 400);
    return () => clearTimeout(t);
  }, [u]);

  const hint = { idle: '3 to 24 characters: letters, numbers, dots and underscores.', checking: 'Checking…', ok: `@${u} is available`, taken: `@${u} is taken`, invalid: '3 to 24 characters: letters, numbers, dots and underscores only.', error: 'Could not check right now. You can still try Next.' }[st];
  const suggestions = st === 'taken' ? [1, 2, 3].map(() => `${u.slice(0, 20)}${Math.floor(10 + Math.random() * 90)}`) : [];

  async function next() {
    if (!user || !USERNAME_RE.test(u)) return;
    setBusy(true); setErr(null);
    try { await claimUsername(user.uid, u, `${first} ${last}`.trim()); } // the live profile changes, so the photo step appears by itself
    catch (e) {
      if ((e as { code?: string }).code === 'permission-denied') { setSt('taken'); setErr('That username was just taken. Try another.'); } else setErr(friendly(e));
    } finally { setBusy(false); }
  }
  return (
    <Screen>
      <Title>Choose a username</Title>
      <Sub>Pick a unique username. You can always change it later.</Sub>
      <Field label="Username" value={u} onChangeText={(t) => setU(t.toLowerCase().replace(/[^a-z0-9._]/g, '').slice(0, 24))} autoCapitalize="none" autoCorrect={false}
        ok={st === 'ok'} bad={st === 'taken' || st === 'invalid'} hint={hint}
        right={st === 'ok' ? <Text style={{ color: C.green, fontSize: 18 }}>✓</Text> : st === 'taken' ? <Text style={{ color: C.red, fontSize: 18 }}>✕</Text> : undefined} />
      {suggestions.length ? <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>{suggestions.map((x) => (
        <Pressable key={x} onPress={() => setU(x)} style={s.chip}><Text style={{ color: C.text }}>{x}</Text></Pressable>))}</View> : null}
      <ErrorText>{err}</ErrorText>
      <Btn title="Next" onPress={next} loading={busy} disabled={st === 'invalid' || st === 'taken' || st === 'checking' || !u} />
    </Screen>
  );
}

/* Step 13: Profile photo, gallery or camera (or skip) */
export function ProfilePhoto() {
  const { user, profile } = useAuth();
  const [img, setImg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const opts = { allowsEditing: true, aspect: [1, 1] as [number, number], quality: 0.7 };
  async function gallery() {
    setErr(null);
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return setErr('Photo access is off. Allow it in your phone settings, or tap Skip.');
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, ...opts });
    if (!r.canceled && r.assets[0]) setImg(r.assets[0].uri);
  }
  async function camera() {
    setErr(null);
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) return setErr('Camera access is off. Allow it in your phone settings, or choose from your gallery.');
    const r = await ImagePicker.launchCameraAsync({ cameraType: ImagePicker.CameraType.front, ...opts });
    if (!r.canceled && r.assets[0]) setImg(r.assets[0].uri);
  }
  async function finish(withPhoto: boolean) {
    if (!user) return;
    setBusy(true); setErr(null);
    try { await finishOnboarding(user.uid, withPhoto && img ? await uploadAvatar(user.uid, img) : null); } // the app opens
    catch (e) { setErr(friendly(e)); } finally { setBusy(false); }
  }
  return (
    <Screen>
      <Title>Add profile photo</Title>
      <Sub>Add a photo so your friends know it's you. You can skip this and add one later.</Sub>
      <View style={{ alignItems: 'center', marginVertical: 18 }}>
        {img ? <Image source={{ uri: img }} style={s.avatar} accessibilityLabel="Your new profile photo" />
          : <View style={[s.avatar, s.avatarEmpty]}><Text style={{ color: C.text, fontSize: 56, fontWeight: '700' }}>{(profile?.username ?? '?').slice(0, 1).toUpperCase()}</Text></View>}
      </View>
      <ErrorText>{err}</ErrorText>
      {img ? <Btn title="Use this photo" onPress={() => finish(true)} loading={busy} /> : null}
      <Btn title="Choose from gallery" variant={img ? 'outline' : 'primary'} onPress={gallery} disabled={busy} />
      <Btn title="Take photo" variant="outline" onPress={camera} disabled={busy} />
      <View style={{ alignItems: 'center', marginTop: 20 }}><Link title="Skip" onPress={() => !busy && finish(false)} /></View>
    </Screen>
  );
}

/* Shown when someone under 18 tries to sign up */
export function Underage() {
  const { clearBlocked } = useAuth();
  return (
    <Screen scroll={false}>
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: C.text, fontSize: 64, fontWeight: '800' }}>18+</Text>
        <Title>You can't join yet</Title>
        <Sub style={{ textAlign: 'center' }}>{AGE_MSG}</Sub>
        <Btn title="OK" onPress={clearBlocked} style={{ alignSelf: 'stretch' }} />
      </View>
    </Screen>
  );
}
const s = StyleSheet.create({
  big: { color: C.text, fontSize: 42, fontWeight: '800', textAlign: 'center' },
  note: { color: C.mute, fontSize: 13, marginBottom: 12, marginLeft: 4 },
  chip: { backgroundColor: C.field2, borderColor: C.border, borderWidth: 1, borderRadius: 99, paddingVertical: 8, paddingHorizontal: 14 },
  avatar: { width: 160, height: 160, borderRadius: 80 },
  avatarEmpty: { backgroundColor: C.field2, borderColor: C.border, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  dobBtn: { backgroundColor: C.field, borderColor: C.border, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, height: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  errBox: { color: C.red, backgroundColor: '#2A1215', borderRadius: 10, padding: 12, marginBottom: 12, fontSize: 14 },
});
