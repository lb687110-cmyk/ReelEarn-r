// Needs the Firebase Blaze (pay-as-you-go) plan to deploy. Without it, run the same logic by hand: node admin/run-fund.js
const functions = require('firebase-functions/v1');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const admin = require('firebase-admin');
admin.initializeApp();
const { runCreatorFund } = require('./fund');

// Every new account gets a wallet (balance 0) the moment it is created.
exports.createWallet = functions.auth.user().onCreate(async (user) => {
  const ref = admin.firestore().doc(`wallets/${user.uid}`);
  if (!(await ref.get()).exists) {
    await ref.set({ balance: 0, pendingTotal: 0, withdrawnTotal: 0, earnedTotal: 0, status: 'active', createdAt: admin.firestore.FieldValue.serverTimestamp() });
  }
});

// 00:05 IST on the 1st of every month.
exports.monthlyCreatorFund = onSchedule({ schedule: '5 0 1 * *', timeZone: 'Asia/Kolkata' }, async () => { await runCreatorFund(admin, new Date()); });
