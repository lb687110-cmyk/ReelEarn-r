import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Text, View } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider, useAuth } from './src/AuthContext';
import { C } from './src/theme';
import { Btn } from './src/ui';
import Home from './src/main/Home';
import Splash from './src/screens/Splash';
import Login from './src/screens/Login';
import ForgotPassword from './src/screens/ForgotPassword';
import { BasicInfo, BirthDate, ChooseMethod, CreatePassword, EnterContact, ProfilePhoto, SignUpLanding, Underage, Username, VerifyCode, VerifyEmail } from './src/screens/SignUp';

const Auth = createNativeStackNavigator();
const theme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: C.bg, card: C.bg, text: C.text, border: C.border, primary: C.blue } };
const opts = { headerShown: false, contentStyle: { backgroundColor: C.bg } } as const;

function Root() {
  const { user, profile, profileError, retryProfile, loading, emailPending, blocked, signOut } = useAuth();
  const [minSplash, setMin] = useState(true);
  useEffect(() => { const t = setTimeout(() => setMin(false), 1800); return () => clearTimeout(t); }, []);

  if (loading || minSplash) return <Splash />;                                   // Step 1
  if (blocked) return <Underage />;                                              // Step 11: under 18
  if (!user) {
    return (                                                                     // Steps 2 to 9: login and sign-up
      <Auth.Navigator screenOptions={opts} initialRouteName="Login">
        <Auth.Screen name="Login" component={Login} />
        <Auth.Screen name="ForgotPassword" component={ForgotPassword} />
        <Auth.Screen name="SignUpLanding" component={SignUpLanding} />
        <Auth.Screen name="ChooseMethod" component={ChooseMethod} />
        <Auth.Screen name="EnterContact" component={EnterContact} />
        <Auth.Screen name="CreatePassword" component={CreatePassword} />
        <Auth.Screen name="VerifyCode" component={VerifyCode} />
      </Auth.Navigator>
    );
  }
  if (emailPending) return <VerifyEmail />;                                      // Step 8 (email)
  if (profileError) {
    return (
      <View style={{ flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <Text style={{ color: C.text, fontSize: 18, fontWeight: '700', marginBottom: 8 }}>Can't load your profile</Text>
        <Text style={{ color: C.mute, textAlign: 'center', marginBottom: 20 }}>Check your internet connection. If this keeps happening, the Firestore rules may not be deployed yet.</Text>
        <Btn title="Try again" onPress={retryProfile} style={{ alignSelf: 'stretch' }} />
        <Btn title="Log out" variant="outline" onPress={signOut} style={{ alignSelf: 'stretch' }} />
      </View>
    );
  }
  if (profile === undefined) return <Splash />;
  // Steps 10 to 13: the saved profile decides which step is next, so closing the app mid-way resumes in the right place.
  if (!profile?.first) return <BasicInfo />;
  if (!profile.dob) return <BirthDate />;
  if (!profile.username) return <Username />;
  if (profile.onboarding === 'photo') return <ProfilePhoto />;
  return <Home />;
}

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <AuthProvider><NavigationContainer theme={theme}><Root /></NavigationContainer></AuthProvider>
    </SafeAreaProvider>
  );
}
