// One-time: creates the fund rules document that firestore.rules reads.   node admin/seed.js
const admin = require('./init');
admin.firestore().doc('fundSettings/main').set({
  enabled: true, ratePerFollower: 0.1, minFollowers: 5000, maxMonthlyInr: 1000000, minAccountAgeDays: 7, minWithdrawInr: 100, maxWithdrawInr: 500000,
}, { merge: true }).then(() => { console.log('fundSettings/main written'); process.exit(0); });
