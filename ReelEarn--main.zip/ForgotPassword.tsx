import React, { useEffect, useState } from 'react';
import { Text } from 'react-native';
import { sendPasswordResetEmail } from 'firebase/auth';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { auth } from '../firebase';
import { EMAIL_RE, friendly } from '../lib';
import { C } from '../theme';
import { Btn, ErrorText, Field, Link, Screen, Sub, Title } from '../ui';

type P = NativeStackScreenProps<any, 'ForgotPassword'>;
const mmss = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

/* Step 3: Forgot password. Firebase emails a reset link. (Mobile-number accounts have no password: they log in with a text code.) */
export default function ForgotPassword({ navigation, route }: P) {
  const pre = String(route.params?.prefill ?? '');
  const [email, setEmail] = useState(EMAIL_RE.test(pre) ? pre : '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [wait, setWait] = useState(0);
  useEffect(() => { if (wait <= 0) return; const t = setTimeout(() => setWait(wait - 1), 1000); return () => clearTimeout(t); }, [wait]);

  async function send() {
    const e = email.trim().toLowerCase();
    if (!EMAIL_RE.test(e)) return setErr('Enter the email address you signed up with.');
    setBusy(true); setErr(null);
    try { await sendPasswordResetEmail(auth, e); setSent(true); setWait(60); }
    catch (x) {
      // Do not reveal whether an account exists for that email.
      if ((x as { code?: string }).code === 'auth/user-not-found') { setSent(true); setWait(60); } else setErr(friendly(x));
    } finally { setBusy(false); }
  }
  return (
    <Screen onBack={() => navigation.goBack()}>
      <Title>Reset your password</Title>
      <Sub>Enter your email and we'll send you a link to choose a new password.{'\n'}Signed up with a mobile number? Go back and log in with a text code.</Sub>
      <Field label="Email address" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" textContentType="emailAddress" />
      <ErrorText>{err}</ErrorText>
      {sent ? <Text style={{ color: C.green, marginBottom: 12 }}>If an account exists for {email.trim()}, a reset link is on its way. Check your spam folder too.</Text> : null}
      <Btn title={sent ? (wait > 0 ? `Send again (${mmss(wait)})` : 'Send again') : 'Send reset link'} onPress={send} loading={busy} disabled={wait > 0} />
      <Link title="Back to log in" onPress={() => navigation.navigate('Login')} style={{ textAlign: 'center', marginTop: 22 }} />
    </Screen>
  );
}
