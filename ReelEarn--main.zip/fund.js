// Creator-fund maths and the monthly run. Used by the Cloud Function (functions/index.js) and by admin/run-fund.js.
// Writes with the Admin SDK, which bypasses firestore.rules, so only this trusted code can credit a wallet.

const DEFAULTS = { enabled: true, ratePerFollower: 0.1, minFollowers: 5000, maxMonthlyInr: 1000000, minAccountAgeDays: 7, minWithdrawInr: 100, maxWithdrawInr: 500000 };
const fundAmount = (n, s) => (!s.enabled || n < s.minFollowers ? 0 : Math.min(s.maxMonthlyInr, Math.floor(n * s.ratePerFollower)));

async function settings(db) {
  const d = await db.doc('fundSettings/main').get();
  return { ...DEFAULTS, ...(d.exists ? d.data() : {}) };
}

/** Followers who count: a real (verified) account at least minAccountAgeDays old. */
async function eligibleFollowers(admin, followerIds, s) {
  const cutoff = Date.now() - s.minAccountAgeDays * 86400000;
  let n = 0;
  for (let i = 0; i < followerIds.length; i += 100) {
    const res = await admin.auth().getUsers(followerIds.slice(i, i + 100).map((uid) => ({ uid })));
    for (const u of res.users) {
      const verified = u.emailVerified || !!u.phoneNumber;
      if (verified && Date.parse(u.metadata.creationTime) <= cutoff) n++;
    }
  }
  return n;
}

/** Credits every creator once per month (safe to run again: each creator+month is written only once). */
async function runCreatorFund(admin, date = new Date()) {
  const db = admin.firestore();
  const s = await settings(db);
  const ym = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  const monthName = date.toLocaleString('en-IN', { month: 'short', year: 'numeric' });
  const byCreator = new Map();
  (await db.collection('follows').get()).forEach((d) => {
    const { followerId, followeeId } = d.data();
    if (!byCreator.has(followeeId)) byCreator.set(followeeId, []);
    byCreator.get(followeeId).push(followerId);
  });
  let credited = 0;
  for (const [uid, followers] of byCreator) {
    const eligible = await eligibleFollowers(admin, followers, s);
    const amount = fundAmount(eligible, s);
    const wRef = db.doc(`wallets/${uid}`);
    if (!(await wRef.get()).exists) {
      await wRef.set({ balance: 0, pendingTotal: 0, withdrawnTotal: 0, earnedTotal: 0, status: 'active', createdAt: admin.firestore.FieldValue.serverTimestamp() });
    }
    await wRef.set({ eligibleFollowers: eligible, estimate: amount }, { merge: true });
    if (amount <= 0) continue;
    const pRef = db.doc(`fundPayouts/${uid}_${ym}`);
    const did = await db.runTransaction(async (tx) => {
      if ((await tx.get(pRef)).exists) return false;
      const w = await tx.get(wRef);
      const cur = w.exists ? w.data() : { balance: 0, pendingTotal: 0, withdrawnTotal: 0, earnedTotal: 0, status: 'active' };
      tx.set(pRef, { userId: uid, month: ym, followers: eligible, amountInr: amount, createdAt: admin.firestore.FieldValue.serverTimestamp() });
      tx.set(wRef, { ...cur, balance: (cur.balance || 0) + amount, earnedTotal: (cur.earnedTotal || 0) + amount, createdAt: cur.createdAt || admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      tx.set(db.collection(`wallets/${uid}/ledger`).doc(`fund_${ym}`), { kind: 'fund', amountInr: amount, note: `Creator fund ${monthName}`, ref: ym, createdAt: admin.firestore.FieldValue.serverTimestamp() });
      return true;
    });
    if (did) credited++;
  }
  return credited;
}
module.exports = { runCreatorFund, DEFAULTS };
