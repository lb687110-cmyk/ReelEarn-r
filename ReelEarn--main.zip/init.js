// Admin scripts run on YOUR computer with a service-account key (Firebase console > Project settings > Service accounts > Generate new private key).
//   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/serviceAccountKey.json
// Never put that key in the app or commit it.
const admin = require('firebase-admin');
admin.initializeApp({ projectId: 'reelearn-c1fd5' });
module.exports = admin;
