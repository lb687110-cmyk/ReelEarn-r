import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Video, ResizeMode } from 'expo-av';
import { collection, deleteDoc, doc, getCountFromServer, getDoc, getDocs, limit, orderBy, query, setDoc, where, documentId } from 'firebase/firestore';
import { useAuth } from '../AuthContext';
import { db } from '../firebase';
import { friendly } from '../lib';
import { num } from '../money';
import { C } from '../theme';
import AdSlot from '../ads/AdSlot';
import { AD_GAPS } from '../ads/config';

type Post = { id: string; owner_id: string; caption: string | null; media_url: string; username: string; photo_url: string | null };
type Item = { type: 'reel'; key: string; post: Post } | { type: 'ad'; key: string; n: number };

/** Puts an ad after every 3rd reel, then every 4th, alternating (3, 4, 3, 4 …). */
export function withAds(posts: Post[]): Item[] {
  const out: Item[] = []; let sinceAd = 0, gap = 0, n = 0;
  for (const p of posts) {
    out.push({ type: 'reel', key: p.id, post: p }); sinceAd++;
    if (sinceAd >= AD_GAPS[gap % AD_GAPS.length]) { out.push({ type: 'ad', key: 'ad-' + n, n }); n++; gap++; sinceAd = 0; }
  }
  return out;
}
const isVideo = (u: string) => /\.(mp4|mov|m4v|webm)(\?|$)/i.test(u);
const chunk = <T,>(a: T[], n: number) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));

/** Likes: posts/{id}/likes/{uid}. Follows: follows/{follower}_{followee}. */
function LikeButton({ post, uid, liked, onToggle }: { post: Post; uid: string; liked: boolean; onToggle: () => void }) {
  const [count, setCount] = useState<number | null>(null);
  useEffect(() => { getCountFromServer(collection(db, 'posts', post.id, 'likes')).then((c) => setCount(c.data().count)).catch(() => undefined); }, [post.id, liked]);
  return (
    <Pressable onPress={onToggle} accessibilityLabel={liked ? 'Unlike' : 'Like'} hitSlop={10} style={{ alignItems: 'center' }}>
      <Text style={[s.icon, liked && { color: C.red }]}>{liked ? '♥' : '♡'}</Text>
      {count !== null ? <Text style={{ color: '#fff', fontWeight: '600' }}>{num(count)}</Text> : null}
    </Pressable>
  );
}

export default function Feed() {
  const { user } = useAuth();
  const uid = user!.uid;
  const [posts, setPosts] = useState<Post[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [liked, setLiked] = useState<Set<string>>(new Set());
  const [following, setFollowing] = useState<Set<string>>(new Set());
  const [h, setH] = useState(0);
  const [cur, setCur] = useState(0);

  const load = useCallback(async () => {
    setErr(null);
    try {
      const snap = await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(40)));
      const raw = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      const owners = [...new Set(raw.map((p) => p.ownerId as string))];
      const by = new Map<string, any>();
      for (const part of chunk(owners, 30)) (await getDocs(query(collection(db, 'profiles'), where(documentId(), 'in', part)))).forEach((d) => by.set(d.id, d.data()));
      setPosts(raw.map((p) => ({ id: p.id, owner_id: p.ownerId, caption: p.caption ?? null, media_url: p.mediaUrl, username: by.get(p.ownerId)?.username ?? 'creator', photo_url: by.get(p.ownerId)?.photoUrl ?? null })));
      const likedIds = await Promise.all(raw.map(async (p) => ((await getDoc(doc(db, 'posts', p.id, 'likes', uid))).exists() ? p.id : null)));
      setLiked(new Set(likedIds.filter(Boolean) as string[]));
      setFollowing(new Set((await getDocs(query(collection(db, 'follows'), where('followerId', '==', uid)))).docs.map((d) => d.data().followeeId as string)));
    } catch (e) { setErr(friendly(e)); setPosts((p) => p ?? []); }
  }, [uid]);
  useEffect(() => { load(); }, [load]);

  const items = useMemo(() => withAds(posts ?? []), [posts]);
  const onView = useRef(({ viewableItems }: any) => { if (viewableItems[0]) setCur(viewableItems[0].index ?? 0); }).current;

  async function toggleLike(p: Post) {
    const on = liked.has(p.id); const next = new Set(liked); on ? next.delete(p.id) : next.add(p.id); setLiked(next);
    try { const r = doc(db, 'posts', p.id, 'likes', uid); on ? await deleteDoc(r) : await setDoc(r, { at: Date.now() }); } catch { setLiked(liked); }
  }
  async function toggleFollow(p: Post) {
    const on = following.has(p.owner_id); const next = new Set(following); on ? next.delete(p.owner_id) : next.add(p.owner_id); setFollowing(next);
    try { const r = doc(db, 'follows', `${uid}_${p.owner_id}`); on ? await deleteDoc(r) : await setDoc(r, { followerId: uid, followeeId: p.owner_id, createdAt: Date.now() }); } catch { setFollowing(following); }
  }

  if (posts === null) return <View style={s.center}><ActivityIndicator color="#fff" /></View>;
  return (
    <View style={{ flex: 1 }} onLayout={(e) => setH(e.nativeEvent.layout.height)}>
      {err ? <Text style={s.err}>{err}</Text> : null}
      {!items.length ? <View style={s.center}><Text style={{ color: C.mute }}>No reels yet. Be the first to post.</Text></View> : h > 0 ? (
        <FlatList data={items} keyExtractor={(i) => i.key} pagingEnabled snapToInterval={h} decelerationRate="fast" showsVerticalScrollIndicator={false}
          getItemLayout={(_, i) => ({ length: h, offset: h * i, index: i })} onViewableItemsChanged={onView} viewabilityConfig={{ itemVisiblePercentThreshold: 80 }}
          windowSize={3} maxToRenderPerBatch={2} initialNumToRender={2} refreshing={false} onRefresh={load}
          renderItem={({ item, index }) => item.type === 'ad'
            ? <View style={{ height: h }}><AdSlot index={item.n} active={index === cur} /></View>
            : <View style={{ height: h, backgroundColor: '#000' }}>
                {isVideo(item.post.media_url)
                  ? <Video source={{ uri: item.post.media_url }} style={StyleSheet.absoluteFill} resizeMode={ResizeMode.COVER} isLooping shouldPlay={index === cur} />
                  : <Image source={{ uri: item.post.media_url }} style={StyleSheet.absoluteFill} resizeMode="cover" />}
                <View style={s.shade} />
                <View style={s.rail}>
                  <LikeButton post={item.post} uid={uid} liked={liked.has(item.post.id)} onToggle={() => toggleLike(item.post)} />
                </View>
                <View style={s.info}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                    {item.post.photo_url ? <Image source={{ uri: item.post.photo_url }} style={s.av} /> : <View style={[s.av, { backgroundColor: C.field2, alignItems: 'center', justifyContent: 'center' }]}><Text style={{ color: '#fff', fontWeight: '700' }}>{item.post.username[0]?.toUpperCase()}</Text></View>}
                    <Text style={s.user}>@{item.post.username}</Text>
                    {item.post.owner_id !== uid ? <Pressable onPress={() => toggleFollow(item.post)} style={s.follow}><Text style={{ color: '#fff', fontWeight: '700', fontSize: 13 }}>{following.has(item.post.owner_id) ? 'Following' : 'Follow'}</Text></Pressable> : null}
                  </View>
                  {item.post.caption ? <Text style={s.cap} numberOfLines={3}>{item.post.caption}</Text> : null}
                </View>
              </View>} />) : null}
    </View>
  );
}
const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 },
  err: { color: C.red, textAlign: 'center', padding: 8 },
  shade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 200, backgroundColor: 'rgba(0,0,0,0.35)' },
  rail: { position: 'absolute', right: 14, bottom: 120 },
  icon: { color: '#fff', fontSize: 38 },
  info: { position: 'absolute', left: 14, right: 70, bottom: 24 },
  av: { width: 38, height: 38, borderRadius: 19 },
  user: { color: '#fff', fontWeight: '700', fontSize: 16 },
  follow: { borderColor: '#fff', borderWidth: 1, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  cap: { color: '#fff', marginTop: 10, lineHeight: 20 },
});
