// Firebase v10 ships some files as .cjs and uses package "exports"; Expo's Metro needs these two lines or Auth fails with
// "Component auth has not been registered yet".
const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);
config.resolver.sourceExts.push('cjs');
config.resolver.unstable_enablePackageExports = false;
module.exports = config;
