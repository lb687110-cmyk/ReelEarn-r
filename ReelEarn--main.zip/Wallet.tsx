import React, { useState } from 'react';
import { ActivityIndicator, Image, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useAuth } from '../AuthContext';
import { useWalletData } from '../db';
import { friendly } from '../lib';
import { inr, monthLabel, num } from '../money';
import { C } from '../theme';
import { Banner, Btn } from '../ui';
import Withdraw from './Withdraw';

const day = (d: Date | null) => (d ? d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Just now');
const STATUS: Record<string, { label: string; color: string }> = { pending: { label: 'Pending', color: '#F5A623' }, processing: { label: 'Processing', color: C.blue }, paid: { label: 'Paid', color: C.green }, rejected: { label: 'Rejected, refunded', color: C.red } };

export default function Wallet() {
  const { user, profile } = useAuth();
  const { wallet, ledger, withdrawals, payouts, rules, followers, err, ready, reload } = useWalletData(user?.uid);
  const [withdraw, setWithdraw] = useState(false);

  if (withdraw && wallet) return <Withdraw rules={rules} balance={wallet.balance} onClose={() => setWithdraw(false)} />;
  if (!wallet) return <View style={s.center}>{err ? <Banner text={friendly({ code: err })} action="Retry" onAction={reload} /> : <ActivityIndicator color="#fff" />}</View>;

  const goal = rules.minFollowers, eligibleNow = wallet.eligibleFollowers ?? 0;
  const pct = Math.min(1, followers / goal), qualifies = followers >= goal;
  const monthly = Math.min(rules.maxMonthlyInr, Math.floor((wallet.eligibleFollowers ?? followers) * rules.ratePerFollower));
  const estimate = (wallet.eligibleFollowers ?? followers) >= goal ? (wallet.estimate ?? monthly) : 0;
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 18, paddingBottom: 40 }} refreshControl={<RefreshControl refreshing={!ready} onRefresh={reload} tintColor="#fff" />}>
      {err ? <Banner text={friendly({ code: err })} action="Retry" onAction={reload} /> : null}
      <View style={s.head}>
        {profile?.photoUrl ? <Image source={{ uri: profile.photoUrl }} style={s.av} /> : <View style={[s.av, { backgroundColor: C.field2, alignItems: 'center', justifyContent: 'center' }]}><Text style={{ color: '#fff', fontSize: 22, fontWeight: '700' }}>{(profile?.username ?? '?')[0]?.toUpperCase()}</Text></View>}
        <View><Text style={s.name}>{profile?.name ?? profile?.username}</Text><Text style={{ color: C.mute }}>@{profile?.username}</Text></View>
      </View>

      <View style={s.card}>
        <Text style={s.lbl}>Wallet balance</Text>
        <Text style={s.bal}>{inr(wallet.balance)}</Text>
        {wallet.pendingTotal > 0 ? <Text style={{ color: '#F5A623', marginTop: 4 }}>{inr(wallet.pendingTotal)} in withdrawal requests being processed</Text> : null}
        {wallet.status === 'frozen' ? <Text style={{ color: C.red, marginTop: 4 }}>Your wallet is on hold. Contact support.</Text> : null}
        <Btn title="Withdraw" onPress={() => setWithdraw(true)} disabled={wallet.balance < rules.minWithdrawInr || wallet.status === 'frozen'} style={{ marginTop: 14 }} />
        {wallet.balance < rules.minWithdrawInr ? <Text style={s.note}>You can withdraw from {inr(rules.minWithdrawInr)}. Up to {inr(rules.maxWithdrawInr)} per request, by UPI or bank transfer.</Text> : null}
      </View>

      <View style={s.card}>
        <Text style={s.lbl}>Creator Fund</Text>
        {!rules.enabled ? <Text style={s.note}>The Creator Fund is paused right now.</Text> : <>
          <Text style={s.big}>{num(followers)} <Text style={s.small}>of {num(goal)} followers</Text></Text>
          <View style={s.track}><View style={[s.fill, { width: `${Math.max(2, pct * 100)}%` }]} /></View>
          <Text style={s.note}>{qualifies ? `You qualify. Estimated next credit: ${inr(estimate || monthly)}` : `${num(goal - followers)} more followers to start earning ${inr(goal * rules.ratePerFollower)} a month.`}</Text>
          <View style={s.row}><Stat k="Followers" v={num(followers)} /><Stat k="Counted last run" v={num(eligibleNow)} /><Stat k="Earned so far" v={inr(wallet.earnedTotal)} /></View>
          <Text style={s.note}>Paid automatically on the 1st of each month into your wallet: {inr(rules.ratePerFollower * 1000)} per 1,000 eligible followers, from {num(goal)} followers, up to {inr(rules.maxMonthlyInr)} a month. On the 1st, only verified accounts at least {rules.minAccountAgeDays} days old are counted. No tasks needed.</Text>
        </>}
      </View>

      <Text style={s.sec}>Withdrawals</Text>
      {withdrawals.length ? withdrawals.map((w) => (
        <View key={w.id} style={s.item}>
          <View style={{ flex: 1 }}><Text style={s.t}>{inr(w.amountInr)} · {w.method === 'upi' ? `UPI ${w.upiId ?? ''}` : `Bank ••${w.last4 ?? ''}`}</Text><Text style={s.sm}>{day(w.at)}{w.adminNote ? ` · ${w.adminNote}` : ''}</Text></View>
          <Text style={{ color: STATUS[w.status]?.color ?? C.mute, fontWeight: '700' }}>{STATUS[w.status]?.label ?? w.status}</Text>
        </View>)) : <Text style={s.empty}>No withdrawals yet.</Text>}

      <Text style={s.sec}>Monthly fund payouts</Text>
      {payouts.length ? payouts.map((p) => (
        <View key={p.id} style={s.item}><View style={{ flex: 1 }}><Text style={s.t}>{monthLabel(p.month)}</Text><Text style={s.sm}>{num(p.followers)} eligible followers</Text></View><Text style={{ color: C.green, fontWeight: '700' }}>+{inr(p.amountInr)}</Text></View>)) : <Text style={s.empty}>Your first payout appears after the next monthly run.</Text>}

      <Text style={s.sec}>Wallet history</Text>
      {ledger.length ? ledger.map((l) => (
        <View key={l.id} style={s.item}><View style={{ flex: 1 }}><Text style={s.t}>{l.note || l.kind}</Text><Text style={s.sm}>{day(l.at)}</Text></View><Text style={{ color: l.amountInr < 0 ? C.text : C.green, fontWeight: '700' }}>{l.amountInr < 0 ? '-' : '+'}{inr(Math.abs(l.amountInr))}</Text></View>)) : <Text style={s.empty}>Nothing here yet.</Text>}
    </ScrollView>
  );
}
const Stat = ({ k, v }: { k: string; v: string }) => <View style={{ flex: 1 }}><Text style={s.statV}>{v}</Text><Text style={s.sm}>{k}</Text></View>;
const s = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', padding: 24 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 16 },
  av: { width: 56, height: 56, borderRadius: 28 }, name: { color: C.text, fontSize: 18, fontWeight: '700' },
  card: { backgroundColor: C.field, borderColor: C.border, borderWidth: 1, borderRadius: 16, padding: 16, marginBottom: 14 },
  lbl: { color: C.mute, fontSize: 13, textTransform: 'uppercase', letterSpacing: 0.6 },
  bal: { color: C.text, fontSize: 40, fontWeight: '800', marginTop: 4 },
  big: { color: C.text, fontSize: 24, fontWeight: '800', marginTop: 6 }, small: { color: C.mute, fontSize: 14, fontWeight: '500' },
  track: { height: 8, backgroundColor: C.field2, borderRadius: 4, marginTop: 12, overflow: 'hidden' }, fill: { height: 8, backgroundColor: C.blue, borderRadius: 4 },
  note: { color: C.mute, fontSize: 13, lineHeight: 19, marginTop: 10 },
  row: { flexDirection: 'row', marginTop: 14 }, statV: { color: C.text, fontSize: 16, fontWeight: '700' },
  sec: { color: C.text, fontSize: 17, fontWeight: '700', marginTop: 12, marginBottom: 8 },
  item: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.field, borderRadius: 12, padding: 12, marginBottom: 8 },
  t: { color: C.text, fontSize: 15 }, sm: { color: C.mute, fontSize: 12, marginTop: 2 }, empty: { color: C.mute, marginBottom: 8 },
});
