import React, { useRef } from 'react';
import { PhoneAuthProvider } from 'firebase/auth';
import { auth, firebaseConfig } from './firebase';

/**
 * Firebase phone sign-in from the JS SDK needs a reCAPTCHA check. In Expo this is provided by expo-firebase-recaptcha
 * (which needs react-native-webview). It is loaded optionally so email sign-in still works if it is not installed:
 *     npx expo install expo-firebase-recaptcha react-native-webview
 */
let Recaptcha: any = null;
try { Recaptcha = require('expo-firebase-recaptcha').FirebaseRecaptchaVerifierModal; } catch { Recaptcha = null; }

export function usePhoneVerifier() {
  const ref = useRef<any>(null);
  const element = Recaptcha ? <Recaptcha ref={ref} firebaseConfig={firebaseConfig} attemptInvisibleVerification /> : null;
  /** Sends the SMS and returns the verification id needed to check the code. */
  async function send(phone: string): Promise<string> {
    if (!Recaptcha) throw new Error('PHONE_MODULE_MISSING');
    return new PhoneAuthProvider(auth).verifyPhoneNumber(phone, ref.current);
  }
  return { element, send };
}
