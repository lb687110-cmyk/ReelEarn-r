import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { signInWithEmailAndPassword } from 'firebase/auth';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CountryPicker } from '../CountryPicker';
import { COUNTRIES, Country, validNational } from '../countries';
import { auth } from '../firebase';
import { EMAIL_RE, friendly } from '../lib';
import { useAuth } from '../AuthContext';
import { usePhoneVerifier } from '../phone';
import { C } from '../theme';
import { Btn, ErrorText, Field, Link, Screen, Sub } from '../ui';

type P = NativeStackScreenProps<any, 'Login'>;

/* Step 2: Login with email + password, or a mobile number + SMS code */
export default function Login({ navigation }: P) {
  const { setDraft } = useAuth();
  const { element, send } = usePhoneVerifier();
  const [mode, setMode] = useState<'email' | 'phone'>('email');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [country, setCountry] = useState<Country>(COUNTRIES[0]);
  const [num, setNum] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function login() {
    setErr(null);
    if (mode === 'email') {
      const e = email.trim().toLowerCase();
      if (!EMAIL_RE.test(e)) return setErr('Enter the email address you signed up with.');
      if (!pw) return setErr('Enter your password.');
      setBusy(true);
      try { await signInWithEmailAndPassword(auth, e, pw); } // success: the app switches screens by itself
      catch (x) { setErr(friendly(x)); } finally { setBusy(false); }
    } else {
      if (!validNational(country, num)) return setErr(country.dial === '+91' ? 'Enter a valid 10-digit mobile number.' : 'Enter a valid mobile number.');
      setBusy(true);
      try {
        const contact = country.dial + num;
        const verificationId = await send(contact);
        setDraft({ method: 'phone', contact, verificationId });
        navigation.navigate('VerifyCode', { purpose: 'login' });
      } catch (x) { setErr(friendly(x)); } finally { setBusy(false); }
    }
  }
  return (
    <Screen>
      {element}
      <View style={{ alignItems: 'center', marginTop: 48, marginBottom: 28 }}><Text style={s.brand}>ReelEarn</Text></View>
      <View style={s.seg}>
        {(['email', 'phone'] as const).map((m) => (
          <Text key={m} onPress={() => { setMode(m); setErr(null); }} accessibilityRole="button" style={[s.segBtn, mode === m && s.segOn]}>{m === 'email' ? 'Email' : 'Mobile number'}</Text>
        ))}
      </View>
      {mode === 'email' ? <>
        <Field label="Email address" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" textContentType="emailAddress" />
        <Field label="Password" value={pw} onChangeText={setPw} secureTextEntry autoCapitalize="none" textContentType="password" />
        <View style={{ alignItems: 'flex-end', marginTop: -4, marginBottom: 14 }}><Link title="Forgot password?" onPress={() => navigation.navigate('ForgotPassword', { prefill: email })} /></View>
      </> : <>
        <View style={{ flexDirection: 'row' }}>
          <CountryPicker value={country} onChange={(c) => { setCountry(c); setNum(num.slice(0, c.max)); }} />
          <View style={{ flex: 1 }}><Field label="Mobile number" value={num} onChangeText={(t) => setNum(t.replace(/\D/g, '').slice(0, country.max))} keyboardType="number-pad" maxLength={country.max} /></View>
        </View>
        <Sub>We'll text you a 6-digit code to log in. There is no password for mobile accounts.</Sub>
      </>}
      <ErrorText>{err}</ErrorText>
      <Btn title={mode === 'email' ? 'Log in' : 'Send code'} onPress={login} loading={busy} />
      <View style={{ flex: 1 }} />
      <View style={{ alignItems: 'center', marginTop: 32, flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
        <Text style={{ color: C.mute }}>Don't have an account?</Text><Link title="Sign up" onPress={() => navigation.navigate('SignUpLanding')} />
      </View>
    </Screen>
  );
}
const s = StyleSheet.create({
  brand: { color: C.text, fontSize: 40, fontWeight: '800', letterSpacing: 0.5 },
  seg: { flexDirection: 'row', backgroundColor: C.field, borderRadius: 12, padding: 4, marginBottom: 18 },
  segBtn: { flex: 1, textAlign: 'center', color: C.mute, fontWeight: '700', paddingVertical: 10, borderRadius: 9, overflow: 'hidden' },
  segOn: { backgroundColor: C.field2, color: C.text },
});
