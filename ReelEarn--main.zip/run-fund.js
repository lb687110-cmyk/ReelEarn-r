// Runs the monthly creator-fund credit by hand (use this if you are not on the Blaze plan).   node admin/run-fund.js
const admin = require('./init');
const { runCreatorFund } = require('../functions/fund');
runCreatorFund(admin, new Date()).then((n) => { console.log(`credited ${n} creators`); process.exit(0); }).catch((e) => { console.error(e); process.exit(1); });
