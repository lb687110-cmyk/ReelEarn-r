// Move a withdrawal along after you have paid (or decided not to pay) it.
//   node admin/set-withdrawal.js <withdrawalId> processing|paid|rejected ["note, e.g. UTR 1234"]
// "rejected" returns the money to the user's wallet.
const admin = require('./init');
const [id, status, note] = process.argv.slice(2);
if (!id || !['processing', 'paid', 'rejected'].includes(status)) { console.error('usage: node admin/set-withdrawal.js <id> processing|paid|rejected [note]'); process.exit(1); }
const db = admin.firestore(), FV = admin.firestore.FieldValue;
db.runTransaction(async (tx) => {
  const wdRef = db.doc(`withdrawals/${id}`), wd = await tx.get(wdRef);
  if (!wd.exists) throw new Error('no such withdrawal');
  const w = wd.data();
  if (['paid', 'rejected'].includes(w.status)) throw new Error(`already ${w.status}`);
  const wRef = db.doc(`wallets/${w.userId}`), wal = (await tx.get(wRef)).data();
  tx.update(wdRef, { status, adminNote: note || null, updatedAt: FV.serverTimestamp() });
  if (status === 'paid') tx.update(wRef, { pendingTotal: wal.pendingTotal - w.amountInr, withdrawnTotal: wal.withdrawnTotal + w.amountInr });
  if (status === 'rejected') {
    tx.update(wRef, { pendingTotal: wal.pendingTotal - w.amountInr, balance: wal.balance + w.amountInr });
    tx.set(db.doc(`wallets/${w.userId}/ledger/refund_${id}`), { kind: 'refund', amountInr: w.amountInr, note: 'Withdrawal refunded' + (note ? ': ' + note : ''), ref: id, createdAt: FV.serverTimestamp() });
  }
}).then(() => { console.log(`withdrawal ${id} -> ${status}`); process.exit(0); }).catch((e) => { console.error(e.message); process.exit(1); });
